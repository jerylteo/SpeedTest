<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'speedtest_e4' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'I+2.PPyO5Sa|+ZLcUv?Tu]K;J06,//OLx;x6UMn[,DKn.pMh.o-Zg2(]<&Ku~Zfr' );
define( 'SECURE_AUTH_KEY',  'blil4qQ[lTeo$%hfGlub9 n+R /5LJ>)YW}};snC,OI!MqnE$.LHtH.*WJ1!#_@v' );
define( 'LOGGED_IN_KEY',    'S7OY-*H6v|l-=R9&:`=Z&~qLy4*v*l2I#5i!+5}F]gNXswv1{h6/~uN2]l X[*X+' );
define( 'NONCE_KEY',        'ffzOS1od9q6TUek%]3I78::Ry!L}4bp<N}D7Sm^wkl5}B^AZgga(BX*$R+lm.xH7' );
define( 'AUTH_SALT',        'Vd}<.%}|opgniqGJxJB/029{~&y#aH *Q#|i9>XEXTClkC4r@F~Y35l{q1~MfhuL' );
define( 'SECURE_AUTH_SALT', 'C3O4UYB>0OiQ{u%{}>Pqn@)Ii,Y,`pgm?;[JYIc5ZbFn[mZG7$b$LP:k+[Lw18X:' );
define( 'LOGGED_IN_SALT',   'K]F/~m-Vdtw|+Rj4&b]diS9v<*bU[cf->SOM t:Ow@i1.n>tZAqWhF@<t>&P[[:a' );
define( 'NONCE_SALT',       'e&TCb6dp8_*8my7AL0P)AnePKynImbX8i;OVUB(GyN{?J.};TW{ND1wdm=!rq.BH' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
