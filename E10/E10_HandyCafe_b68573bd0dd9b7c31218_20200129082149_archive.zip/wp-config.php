<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '7etsCsL[!FG5m)qPJ7gXCBOISu8(`LueMc5|hb#=>tc,],u.i+#;uWeN2jvU7^Y5' );

define( 'SECURE_AUTH_KEY',  'xK3g:eB3I44rzxNP9@|6fVW!AH`C$ba]W~%>o%U;reXQK?,P.yz]sFqGW/BZ@_RT' );

define( 'LOGGED_IN_KEY',    'D2WMs&Q@O7L%}x:]pyy=uEbeSvs4(cOJXU9p5k:d@x!AF/P_^`vd7,<h`!hEKdu:' );

define( 'NONCE_KEY',        'hR@d[AS-!RTO4q)}[9t,q/Z!40SMSdm0U`R^;SH`0m`0YMOK%7mz*UBi24k8FQGv' );

define( 'AUTH_SALT',        ' wDgg81trexq-GxZ].`tl>fkzx@`5t nc&AIJLm6*T[q7eR.67DM*Q;NB>[hp))z' );

define( 'SECURE_AUTH_SALT', 'uF2(?QJ_T}}f+lD2!=U]mwP*:c:}Zzo=]%Fxy4]-4.0(7tnx!=XE8MD?u[Tsrq%c' );

define( 'LOGGED_IN_SALT',   '?uMWaYO.Z`:LFgq`KY<X`NNdbBkOS@qC|b>cLPkk%<a#,Jnb<Y7:c.Z_v6?/.47(' );

define( 'NONCE_SALT',       'n}WN%| 0WD$b_hg4O~7&)CkEzhsra,21!&vdYWP8WE,;BtKq9y!&!1i^|,o4^^!3' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'tb_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

