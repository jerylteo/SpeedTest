<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'speedtest_e3' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'P+0jBDYi7kF?GPi/&H5us:&M&g[d:#%Q#g72;^o]U@eiBrOy2$5w[7J][lD#IJjy' );
define( 'SECURE_AUTH_KEY',  'SAX^#}0<OY,A]PZ*+]/!f!)6kj%9n/_cq-Z}P!R5F8TW+vj8XbvCKp[(o7fQtJfa' );
define( 'LOGGED_IN_KEY',    '1sB#=sSQhpm]5|*&Z,&{~mE+x_bz;qoI*9@T1k<Kq&^1[[OPn8;GUop<ZY2cWZNd' );
define( 'NONCE_KEY',        'N&OB7D,oArue|oA{I*?F5RNlB&Q3GpBdo4-:Z_(eG7x>pm)?!#Z*hQhwJ>j3qlzz' );
define( 'AUTH_SALT',        'nF:*gxZ[_p((y~Dp:&&>x0tP:GjM.+^A>O#IIcZ>hn4Z]Xdvt4gkC^m8!,(&{Yel' );
define( 'SECURE_AUTH_SALT', 'QT3^L&!K#:/p0aWy$J[_.BRA*E*C]Ue@fU?W8^<Ac MO1~gczjgeoK%n+..NX4#N' );
define( 'LOGGED_IN_SALT',   '7|`aB%!zhZoJZRVQLdS7(meO,o*H1s(1(^B.y9:%iaM@xm!$ /u>#o/n`Svt*nMu' );
define( 'NONCE_SALT',       '3Mi}eBl9#-gqO:uh ]@h$x ?Tef(=dP:Gn7pEH{ZK+PhQpNgb p|C:Bd:RAsJ6s$' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
